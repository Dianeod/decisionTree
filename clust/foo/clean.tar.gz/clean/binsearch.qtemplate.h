#include "k.h"
qtemplate({"names":["binsearch"],"types":["QT1"],"ptypes":{"QT1":["H","I","J","F","E"]}}|
J binsearch(QT1* x,QT1 y,J lw,J min,J hw);)
